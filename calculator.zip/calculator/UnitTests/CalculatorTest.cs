﻿using Microsoft.VisualStudio.TestPlatform.TestHost;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests
{
    [TestClass]
    public class CalculatorTest
    {
        [TestMethod]
        public async Task Opn1()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn1 = cal.CalOperation("20");
            Assert.AreEqual(20, opn1);

        }
        [TestMethod]
        public async Task Opn2()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn2 = cal.CalOperation("1,5000");
            Assert.AreEqual(1, opn2);
        }
        [TestMethod]

        public async Task Opn3()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn3 = cal.CalOperation("4,-3");
            Assert.AreEqual(1, opn3);
        }
        [TestMethod]

        public async Task Opn4()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn4 = cal.CalOperation("");
            Assert.AreEqual(0, opn4);
        }
        [TestMethod]

        public async Task Opn5()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn5 = cal.CalOperation("5,tytyt");
            Assert.AreEqual(5, opn5);
        }
        [TestMethod]

        public async Task Opn6()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn6 = cal.CalOperation("1,2,3,4,5,6,7,8,9,10,11,12");
            Assert.AreEqual(78, opn6);
        }
        [TestMethod]

        public async Task Opn7()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn7 = cal.CalOperation("1\n2,3");
            Assert.AreEqual(6, opn7);
        }
        [TestMethod]

        public async Task Opn8()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn8 = cal.CalOperation("2,1001,6");
            Assert.AreEqual(8, opn8);
        }
        [TestMethod]

        public async Task Opn9()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn9 = cal.CalOperation("//#\n2#5");
            Assert.AreEqual(7, opn9);
        }
        [TestMethod]

        public async Task Opn10()
        {
            calculator.Calculation cal = new calculator.Calculation();
            int opn10 = cal.CalOperation("//,\n2,ff,100");
            Assert.AreEqual(102, opn10);
        }
    }
}

