﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;

namespace calculator
{
  public class Program
    {
        static void Main(string[] args)
        {
            var objCal = new Calculation();
            int opn1 = objCal.CalOperation("20");
            Console.WriteLine(opn1);
            int opn2 = objCal.CalOperation("1,5000");
            Console.WriteLine(opn2);
            int opn3 = objCal.CalOperation("4,-3");
            Console.WriteLine(opn3);
            int opn4 = objCal.CalOperation("");
            Console.WriteLine(opn4);
            int opn5 = objCal.CalOperation("5,tytyt");
            Console.WriteLine(opn5);
            int opn6 = objCal.CalOperation("1,2,3,4,5,6,7,8,9,10,11,12");
            Console.WriteLine(opn6);
            int opn7 = objCal.CalOperation("1\n2,3");
            Console.WriteLine(opn7);
            int opn8 = objCal.CalOperation("2,1001,6");
            Console.WriteLine(opn8);
            int opn9 = objCal.CalOperation("//#\n2#5");
            Console.WriteLine(opn9);
            int opn10 = objCal.CalOperation("//,\n2,ff,100");
            Console.WriteLine(opn10);
            Console.WriteLine("--------------------------------------------------------------------");
            Console.WriteLine("--------------------------------------------------------------------");
            Console.WriteLine("Stretch goals");
            Console.WriteLine("Enter input:");
            string input=  Console.ReadLine();
            int op1 = objCal.CalOperation(input);
            Console.WriteLine("This is the output: " + op1);
            Console.WriteLine("Enter input:");
            string input2 = Console.ReadLine();
            int op2 = objCal.CalOperation(input2);
            Console.WriteLine("This is the output: " + op2);
            Console.WriteLine("Enter input:");
            string input3 = Console.ReadLine();
            int op3 = objCal.CalOperation(input3);
            if(op3>0)
            {
                Console.WriteLine("This is the output: " + op3);
            }
            else
            {
                Console.WriteLine("Output is Negative number");
            }
            Console.WriteLine("Enter input:");
            string input4 = Console.ReadLine();
            int op4 = objCal.CalOperation(input4);
            Console.WriteLine("This is the output: " + op4);

        }
    }
    public class Calculation
    {
        public int CalOperation(string value)
        {
            int mos = 0;
            int sum = 0;
            var intList = value.Replace("\n", ",").Replace("#", ",").Split(',')
                    .Select(m => { int.TryParse(m, out mos); return mos; })
                    .Where(m => m != 0 || m < 1000)
                    .ToList();
            for (int i = 0; i < intList.Count; i++)
            {
                if (intList[i] <= 1000)
                {
                    sum += intList[i];
                }
            }
            return sum;
        }
    }
}
